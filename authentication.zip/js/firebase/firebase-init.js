import { initializeApp } from "https://www.gstatic.com/firebasejs/11.2.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.2.0/firebase-auth.js";


//내꺼-본인껄로 반드시 반드시 꼭 꼭 바꾸세요
const firebaseConfig = {
    apiKey: "AIzaSyDNLO1SQqbfHz87OXO-Z-t8eFngWBRedBs",
    authDomain: "auth-demo-9c139.firebaseapp.com",
    projectId: "auth-demo-9c139",
    storageBucket: "auth-demo-9c139.firebasestorage.app",
    messagingSenderId: "217393073414",
    appId: "1:217393073414:web:7c945d14ce49af69fca287",
    measurementId: "G-1ZCYG1BTZN"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app)

  export {app, auth}