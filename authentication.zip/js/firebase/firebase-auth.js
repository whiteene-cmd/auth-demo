import { auth } from './firebase-init.js';

import {
    createUserWithEmailAndPassword, //회원가입
    signInWithEmailAndPassword, //로그인
    updateProfile, //프로필 표시 이름
    sendEmailVerification, //이메일 인증 보내기
    GoogleAuthProvider,
    GithubAuthProvider,
    signInWithPopup,
} from "https://www.gstatic.com/firebasejs/11.2.0/firebase-auth.js";

//회원가입 함수
export const signup = async(email, password, displayName) => {
    const userCredential = await createUserWithEmailAndPassword(
        //계정생성 - 이메일, 비번, 사용자이름 정보는 userCredential에 저장
        auth,
        email,
        password
    );

    //방금 가입한 사용자의 이름(nickname)을 Firebase 사용자 정보에 저장
    await updateProfile(userCredential.user, {
        //방금 회원가입해서 생성된 사용자 객체
        displayName: displayName //사용자 이름으로저장할 값
    })

    //사용자의 이메일 주소로 인증
    await sendEmailVerification(userCredential.user);

    return userCredential.user
}

//구글로그인
export const googleLogin = async () => {
  try {
    const provider = new GoogleAuthProvider();
    const result = await signInWithPopup(auth, provider);
    const user = result.user;

    console.log("google 로그인 성공: ", user);
    return user;
  } catch (error) {
    if (error.code === "auth/popup-closed-by-user") {
      throw new Error("로그인 창이 닫혔습니다. 다시 시도해주세요.");
    } else if (error.code === "auth/network-request-failed") {
      throw new Error(
        "네트워크 오류가 발생했습니다. 인터넷 연결을 확인해주세요."
      );
    } else {
      console.error("google 로그인 실패: ", error);
      throw new Error("구글 로그인에 실패했습니다. 다시 시도해주세요");
    }
  }
};


//github 로그인
export const githubLogin = async () => {
  try {
    const provider = new GithubAuthProvider();
    const result = await signInWithPopup(auth, provider);
    const user = result.user;

    console.log("Github 로그인 성공: ", user);
    return user;
  } catch (error) {
    if (error.code === "auth/popup-closed-by-user") {
      throw new Error("로그인 창이 닫혔습니다. 다시 시도해주세요.");
    } else if (error.code === "auth/network-request-failed") {
      throw new Error(
        "네트워크 오류가 발생했습니다. 인터넷 연결을 확인해주세요."
      );
    } else {
      console.error("Github 로그인 실패: ", error);
      throw new Error("깃허브 로그인에 실패했습니다. 다시 시도해주세요");
    }
  }
};

// login이라는 로그인 함수를 만듭니다.
export const login = async (email, password) => {
  //이메일과 비밀번호로 로그인 시도하고, 로그인 성공 시 정보를 userCredential에 저장합니다.
  try {
    const userCredential = await signInWithEmailAndPassword(
      auth,
      email,
      password
    );

    //만약 사용자가 이메일 인증을 안 했다면, 에러를 발생시켜 로그인 실패 처리합니다.
    if (!userCredential.user.emailVerified) {
      throw new Error("이메일 인증이 필요합니다. 이메일을 확인해주세요.");
    }

    //로그인에 성공하면 콘솔에 사용자 정보를 출력합니다 (개발 확인용).
    console.log("로그인 성공: ", userCredential.user);

    //로그인된 사용자 객체를 결과로 반환합니다.
    return userCredential.user;
  } catch (error) {
    //이메일이나 비밀번호가 틀렸을 때 보여줄 사용자 메시지를 설정합니다.
    if (error.code === "auth/invalid-credential") {
      throw new Error("이메일 또는 비밀번호가 올바르지 않습니다.");
    } else if (error.code === "auth/too-many-requests") {
      throw new Error(
        "너무 많은 로그인 시도가 있었습니다. 잠시 후 다시 시도해주세요."
      );
    } else {
      throw error;
    }
  }
};